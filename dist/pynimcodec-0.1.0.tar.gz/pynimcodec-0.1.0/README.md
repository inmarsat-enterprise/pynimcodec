# pynimcodec

A set of message codecs for use with satellite IoT products implemented
in Python.