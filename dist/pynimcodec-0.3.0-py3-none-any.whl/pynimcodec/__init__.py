"""Message codecs for use with Non-IP modems for satellite IoT."""
